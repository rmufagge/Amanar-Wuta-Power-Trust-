# Ma'ahad Academic Management — CZ Production

**Release package:** 0.7.0 (nine-subject register, comment approval and signature management)  
**School:** Ma'ahad Sheikh Gwani Jamilu Yusha'u Littahsin Qira'atil Qur'an Waddirasa tul Islamiyya  
**Developer brand:** CZ Production — Technology You Can Trust.

## What is included

- Responsive school-branded web interface and PWA manifest/service worker.
- Official school crest and app icons supplied for this project.
- Supabase Auth sign-in using the project's public publishable key.
- Live reads/writes against the configured Supabase database, protected by Row Level Security.
- Seven seeded Bayt classrooms and nine subjects from the manual report sheet (Qur'an, Hadith, Sira, Tauhid, Fiqhu, Kaddi, Tajweed, Tahzib and Azkar).
- Student registration/enrolment for administrators.
- Class-specific subject allocation and teacher/class/subject assignments.
- CA (0–40) and examination (0–60) entry with automatic total and provisional grade.
- IndexedDB local outbox for offline score entry and retry-on-reconnect synchronisation.
- Result submission and admin approval/return workflow foundation.

## Connected Supabase backend

- Project ref: `icvckjguwhyqvnivbzyt`
- Project URL: `https://icvckjguwhyqvnivbzyt.supabase.co`
- Region: `eu-west-2`
- The publishable key is configured in `app.js`. It is designed to be public. No service-role key or database password is included.
- Initial schema, seed data, Row Level Security policies, profile bootstrap trigger and indexes have been applied to this project.

## Critical setup before staff use

The backend does not contain any staff accounts yet. The school owner must create the first administrator account and assign its role. No password has been generated or stored in this package.

1. Open the Supabase project dashboard: `https://supabase.com/dashboard/project/icvckjguwhyqvnivbzyt`.
2. Go to Authentication → Users → Add user. Create the head teacher/admin using an email address controlled by the school. Add `full_name` in user metadata if available.
3. Copy that user's UUID.
4. In SQL Editor, run the following, replacing the UUID:

```sql
update public.profiles
set role = 'school_admin', is_active = true
where id = 'REPLACE-WITH-AUTH-USER-UUID';
```

5. Before entering official scores, configure the correct academic term status. The seeded 2026/2027 First Term is deliberately `setup`, not assumed open. To open it after school approval:

```sql
update public.academic_terms t
set status = 'open'
from public.academic_sessions s
where t.session_id = s.id
  and s.name = '2026/2027'
  and t.term_order = 1;
```

6. Sign in to the app with the admin account. Allocate the actual subjects to each of the seven classes. Do not assume every class studies all eight subjects.
7. Create teacher accounts in Authentication → Users. The database trigger creates each new account's default `teacher` profile. Then use the app's Class & subject setup to assign each teacher to the relevant class and subject.
8. Register students and enrol them in the correct class for 2026/2027.
9. Test with dummy student records and two staff accounts before importing real pupil information.

## Deployment

This is a static PWA source package. Deploy the contents of this folder to a static HTTPS host (Vercel, Netlify, or another host) with the site root set to this folder. HTTPS is required for service-worker installation and PWA offline caching.

A Vercel project creation attempt through the connected Vercel account was rejected with HTTP 403 `forbidden` (the connected account lacks permission to create projects). No production URL has therefore been created. Once the Vercel team owner grants project-creation permission or links an existing project, import this folder and deploy it.

## Offline and sync behaviour

- The app shell and previously loaded records can be cached for offline use after the first successful online visit.
- Scores entered offline are stored in IndexedDB on that browser/device.
- On reconnection, pending records are submitted to Supabase under the signed-in user's JWT and RLS policies.
- A previously authenticated device is required; first-time sign-in and initial data download require internet.
- This pilot sync flow must be acceptance-tested with real teacher assignments and dummy students before official use. Keep periodic exports/backups during pilot testing.

## Academic calculation

- CA maximum: 40.
- Final examination maximum: 60.
- Subject total: CA + examination, out of 100.
- The displayed A–F grade boundaries in the UI are provisional examples (A 80+, B 70–79, C 60–69, D 50–59, E 40–49, F below 40). Confirm the school's official grading policy before publishing results.
- Class rank, aggregate and final report-card PDF generation are not yet included in this pilot release.

## Security notes

- Public publishable key only; never add a Supabase service-role key to browser code.
- RLS is enabled on the application tables. Anonymous RPC execution for the helper functions has been revoked and verified.
- Teachers should only receive their assigned class/subject access.
- Do not enter real pupil records until admin account bootstrap, class allocations, teacher assignments, term opening, device controls and the pilot acceptance checks are complete.

## Local test

Run a local static server from this folder, then open its HTTPS/localhost URL in Chrome. For example, on a computer with Python installed:

```bash
python -m http.server 8080
```

Open `http://localhost:8080` for local interface testing. PWA installation and remote Supabase requests require the appropriate secure origin and network access.

## Pilot refinement 0.3
See `CHANGELOG-PILOT-0.3.txt`. This package adds mobile access to administration screens, teacher account management integration, class-filtered teacher subject assignments, and academic term opening controls. Deploy the updated static files to the existing Vercel project after verifying the Supabase function `admin-create-teacher` is active.


## Pilot refinement 0.4
This release improves the administrator workflow with a guided school setup wizard, setup progress checklist, active academic-term selector, streamlined six-item mobile navigation, dashboard setup shortcut, and automatic admission-number suggestion. It is a frontend update for the existing Vercel project and existing Supabase backend. Review `CHANGELOG-PILOT-0.4.txt` and `DEPLOYMENT-CHECKLIST.txt` before publishing.

## Pilot refinement 0.5 — Results & report cards

This release adds an administrator Results & Report Cards workspace under the Results navigation:

- Filter by academic term and classroom.
- Read approved scores only from `student_scores`.
- Compare every enrolled learner against compulsory subjects allocated to that classroom/session.
- Flag incomplete results and prevent class-pack PDF printing until every enrolled student has all required approved marks.
- Print one learner's report card or the entire class pack using the browser print dialog (choose Save as PDF on Android/desktop).
- Export the selected class results register as CSV for Excel/Google Sheets.
- Display class position, aggregate and average only when the learner has a complete approved result.
- Keep report cards marked PILOT COPY until the school confirms official grade boundaries and publication policy.
- Show result submissions as compact cards on phones to avoid clipped teacher IDs/columns; teacher names are loaded through the verified foreign-key relationship.

No database migration is required. The feature uses existing tables and authenticated Supabase REST access with the existing RLS policies. Closed terms are now included in the report filter for historical result access within the active academic session.


## Pilot refinement 0.7 — manual report-card workflow

See `CHANGELOG-PILOT-0.7.txt` and migration `supabase/migrations/20261120_report_comments_signatures_v07.sql`. The connected database migration has been applied. This release adds the ninth subject (Tajweed), teacher-editable overall comments with headmaster approval, and administrator signature/stamp uploads stored in a private school-scoped Supabase Storage bucket. The teacher comment workflow is available in Results. Admin loads approved scores to seed the automatic suggestion; the designated class teacher edits/submits; the headmaster approves; only then is the report printable.

**Grading policy remains unconfirmed.** The supplied manual sheet image shows only the first three grade-analysis bands clearly (00–39 F9 Fail; 40–44 E8 Pass; 45–49 D7 Pass). Obtain a clear full image of the complete Remark Analysis box before locking the grade mapping. The existing front-end grade mapping remains provisional.

## v0.7.1 QA refinements

- Canonical nine-subject spelling and display order.
- Concise subject grade remarks and one overall teacher-edited comment.
- Optional behaviour/conduct observation.
- Totals row in the report table.
- Signed report printing requires the designated teacher and headmaster signatures.
- Official grading legend remains incomplete in the supplied photograph; reports retain PILOT COPY watermark.
