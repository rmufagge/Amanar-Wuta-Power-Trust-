Ma'ahad Academic v0.6.0 — CZ Production

This release implements the school's requested subject mark breakdown:
- Attendance: 20
- Test / Assignment: 20
- Final Examination: 60
- CA total: 40
- Subject total: 100

The app calculates the CA and final total automatically, saves all three components to the offline queue, and synchronises the components to Supabase.

Report cards show all components per subject, grade, subject remark, aggregate, average, class position, automatic teacher and headmaster comments, assigned classroom teacher names with individual signature lines, and a Headmaster/Principal signature and school-stamp space. Enter the Headmaster/Principal printed name in the report page before loading/printing.

Database migration: supabase/migrations/20261120_assessment_breakdown_v06.sql
The migration has already been applied to the connected production Supabase project. It is included for staging/other environments.

Compatibility note: existing records only have a combined CA score. The system does not invent a split between attendance and test/assignment. Old records remain intact but are flagged incomplete for the new report-card format until the two CA components are entered and approved.

Signature note: the system prints authorised signatory names and provides signature spaces. It does not fabricate handwritten signatures.

Deploy frontend files to the existing Vercel project. See DEPLOYMENT-CHECKLIST-0.6.txt.
