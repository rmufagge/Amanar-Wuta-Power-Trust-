-- Run only after creating the first administrator in Supabase Authentication > Users.
-- Replace the UUID with the new auth.users.id. Never share the user's password.
update public.profiles
set role = 'school_admin', is_active = true
where id = 'REPLACE-WITH-AUTH-USER-UUID';

-- After the school confirms the academic calendar, open the correct term.
-- The first term is intentionally seeded as setup pending school confirmation.
update public.academic_terms t
set status = 'open'
from public.academic_sessions s
where t.session_id = s.id
  and s.name = '2026/2027'
  and t.term_order = 1;
