import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
    if (!token) return json({ error: "Authentication required" }, 401);
    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    if (!url || !anon || !serviceKey) return json({ error: "Server configuration incomplete" }, 500);
    const callerClient = createClient(url, anon, { global: { headers: { Authorization: `Bearer ${token}` } } });
    const { data: callerData, error: callerError } = await callerClient.auth.getUser(token);
    if (callerError || !callerData.user) return json({ error: "Invalid session" }, 401);
    const admin = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
    const { data: callerProfile, error: profileError } = await admin.from("profiles").select("id, school_id, role, is_active").eq("id", callerData.user.id).single();
    if (profileError || !callerProfile || !callerProfile.is_active || !["school_admin", "super_admin"].includes(callerProfile.role)) return json({ error: "Only an active school administrator can create teacher accounts" }, 403);
    const body = await req.json();
    const fullName = String(body.full_name || "").trim();
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.temporary_password || "");
    if (fullName.length < 2 || fullName.length > 120) return json({ error: "Enter a valid teacher name" }, 400);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: "Enter a valid email address" }, 400);
    if (password.length < 12) return json({ error: "Temporary password must be at least 12 characters" }, 400);
    const { data: created, error: createError } = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { full_name: fullName, school_id: callerProfile.school_id } });
    if (createError || !created.user) return json({ error: createError?.message || "Could not create teacher account" }, 400);
    const { data: teacherProfile, error: teacherError } = await admin.from("profiles").select("id, full_name, role, school_id, is_active").eq("id", created.user.id).single();
    if (teacherError || !teacherProfile || teacherProfile.school_id !== callerProfile.school_id || teacherProfile.role !== "teacher") {
      await admin.auth.admin.deleteUser(created.user.id);
      return json({ error: "Teacher profile validation failed; account creation was rolled back" }, 500);
    }
    await admin.from("audit_logs").insert({ actor_id: callerData.user.id, action: "teacher_account_created", entity_type: "profile", entity_id: created.user.id, details: { email, full_name: fullName } });
    return json({ teacher: { id: teacherProfile.id, full_name: teacherProfile.full_name, email, role: teacherProfile.role } }, 201);
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : "Unexpected server error" }, 500);
  }
});
