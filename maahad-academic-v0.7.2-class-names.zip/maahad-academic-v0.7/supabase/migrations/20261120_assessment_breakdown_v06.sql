-- Ma'ahad Academic v0.6.0 assessment breakdown migration
-- Adds the school's confirmed per-subject structure: attendance 20 + test/assignment 20 + exam 60.
-- Existing combined CA values are intentionally NOT split because the original attendance/test components cannot be inferred safely.

alter table public.student_scores
  add column if not exists attendance_score numeric(5,2),
  add column if not exists assessment_score numeric(5,2);

do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'student_scores_attendance_score_range') then
    alter table public.student_scores add constraint student_scores_attendance_score_range
      check (attendance_score is null or attendance_score between 0 and 20);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'student_scores_assessment_score_range') then
    alter table public.student_scores add constraint student_scores_assessment_score_range
      check (assessment_score is null or assessment_score between 0 and 20);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'student_scores_exam_score_range_v2') then
    alter table public.student_scores add constraint student_scores_exam_score_range_v2
      check (exam_score is null or exam_score between 0 and 60);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'student_scores_ca_components_match') then
    alter table public.student_scores add constraint student_scores_ca_components_match
      check (attendance_score is null or assessment_score is null or ca_score = attendance_score + assessment_score);
  end if;
end $$;
