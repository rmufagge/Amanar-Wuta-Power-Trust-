-- Ma'ahad Academic v0.7.0 — nine subjects, teacher comments and report signatures
-- Applied to the connected Supabase project on 2026-11-20.

insert into public.subjects (school_id,name,active)
select '11111111-1111-4111-8111-111111111111'::uuid,'Tajweed',true
where not exists (select 1 from public.subjects where school_id='11111111-1111-4111-8111-111111111111'::uuid and lower(name)='tajweed');

update public.subjects set name='Sira' where school_id='11111111-1111-4111-8111-111111111111'::uuid and name='Sirah';
update public.subjects set name='Tauhid' where school_id='11111111-1111-4111-8111-111111111111'::uuid and name='Tauheed';
update public.subjects set name='Kaddi' where school_id='11111111-1111-4111-8111-111111111111'::uuid and name='Khaddi';
update public.subjects set name='Tahzib' where school_id='11111111-1111-4111-8111-111111111111'::uuid and name='Tahzeeb';

alter table public.profiles add column if not exists signature_path text;
alter table public.classrooms add column if not exists class_teacher_id uuid references public.profiles(id);
grant update on public.classrooms to authenticated;
alter table public.schools add column if not exists headmaster_name text, add column if not exists headmaster_signature_path text, add column if not exists school_stamp_path text;

create table if not exists public.report_card_comments (
 id uuid primary key default gen_random_uuid(),
 school_id uuid not null references public.schools(id) on delete cascade,
 enrollment_id uuid not null references public.enrollments(id) on delete cascade,
 term_id uuid not null references public.academic_terms(id) on delete cascade,
 teacher_id uuid not null references public.profiles(id),
 suggested_comment text not null,
 teacher_comment text not null,
 conduct_remark text,
 status text not null default 'draft' check(status in ('draft','submitted','approved','returned')),
 approved_by uuid references public.profiles(id), approved_at timestamptz,
 updated_at timestamptz not null default now(), created_at timestamptz not null default now(),
 unique(enrollment_id,term_id)
);
alter table public.report_card_comments enable row level security;
grant select, insert, update on public.report_card_comments to authenticated;
grant update on public.schools to authenticated;
grant update on public.profiles to authenticated;
drop policy if exists "report comments read scoped" on public.report_card_comments;
create policy "report comments read scoped" on public.report_card_comments for select to authenticated using (
 school_id=public.current_school_id() and (public.is_school_admin() or teacher_id=auth.uid() or exists (
  select 1 from public.enrollments e join public.classrooms c on c.id=e.classroom_id where e.id=report_card_comments.enrollment_id and c.class_teacher_id=auth.uid()
 )));
drop policy if exists "teachers submit report comments" on public.report_card_comments;
create policy "teachers submit report comments" on public.report_card_comments for insert to authenticated with check (
 school_id=public.current_school_id() and teacher_id=auth.uid() and status in ('draft','submitted') and exists (
  select 1 from public.enrollments e join public.academic_terms t on t.id=report_card_comments.term_id join public.teacher_assignments a on a.classroom_id=e.classroom_id and a.session_id=t.session_id where e.id=report_card_comments.enrollment_id and a.teacher_id=auth.uid() and a.active
 ));
drop policy if exists "assigned teachers update pending report comments" on public.report_card_comments;
drop policy if exists "assigned class teachers update pending report comments" on public.report_card_comments;
create policy "assigned class teachers update pending report comments" on public.report_card_comments for update to authenticated using (
 status in ('draft','returned') and exists (select 1 from public.enrollments e join public.classrooms c on c.id=e.classroom_id where e.id=report_card_comments.enrollment_id and c.class_teacher_id=auth.uid())
) with check (
 teacher_id=auth.uid() and status in ('draft','submitted','returned') and exists (select 1 from public.enrollments e join public.classrooms c on c.id=e.classroom_id where e.id=report_card_comments.enrollment_id and c.class_teacher_id=auth.uid())
);
drop policy if exists "admins manage report comments" on public.report_card_comments;
create policy "admins manage report comments" on public.report_card_comments for all to authenticated using (school_id=public.current_school_id() and public.is_school_admin()) with check (school_id=public.current_school_id() and public.is_school_admin());

drop policy if exists "school admins update own school settings" on public.schools;
create policy "school admins update own school settings" on public.schools for update to authenticated using (id=public.current_school_id() and public.is_school_admin()) with check (id=public.current_school_id() and public.is_school_admin());

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('maahad-signatures','maahad-signatures',false,2097152,array['image/png','image/jpeg','image/webp'])
on conflict(id) do update set public=false,file_size_limit=2097152,allowed_mime_types=array['image/png','image/jpeg','image/webp'];
drop policy if exists "school members read signatures" on storage.objects;
create policy "school members read signatures" on storage.objects for select to authenticated using (bucket_id='maahad-signatures' and (storage.foldername(name))[1]=public.current_school_id()::text);
drop policy if exists "admins upload signatures" on storage.objects;
create policy "admins upload signatures" on storage.objects for insert to authenticated with check (bucket_id='maahad-signatures' and (storage.foldername(name))[1]=public.current_school_id()::text and public.is_school_admin());
drop policy if exists "admins update signatures" on storage.objects;
create policy "admins update signatures" on storage.objects for update to authenticated using (bucket_id='maahad-signatures' and (storage.foldername(name))[1]=public.current_school_id()::text and public.is_school_admin()) with check (bucket_id='maahad-signatures' and (storage.foldername(name))[1]=public.current_school_id()::text and public.is_school_admin());
drop policy if exists "admins delete signatures" on storage.objects;
create policy "admins delete signatures" on storage.objects for delete to authenticated using (bucket_id='maahad-signatures' and (storage.foldername(name))[1]=public.current_school_id()::text and public.is_school_admin());

-- Preserve the manual report's optional behaviour/conduct field.
alter table public.report_card_comments add column if not exists conduct_remark text;
